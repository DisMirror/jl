package com.xz.oauth2.service;

import com.xz.oauth2.entity.dto.Client;

import java.util.List;

public interface ClientService {
    List<Client> findByAll();
}

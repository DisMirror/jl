package com.xz.oauth2.dao;

import com.xz.oauth2.entity.dto.Users;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UsersDao {
    @Select("select * from users where username = '#{username}'")
    Users finByUsername(@Param("username")String username);

}

package com.xz.oauth2.service.impl;

import com.xz.oauth2.dao.UsersDao;
import com.xz.oauth2.entity.dto.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class DbUserDetailsService implements UserDetailsService {
    @Autowired
    private UsersDao usersDao;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users users=usersDao.finByUsername(username);
        if(users==null){
            throw new UsernameNotFoundException("User not found!" + username);
        }else{
            new User(username,users.getPassword(), AuthorityUtils.createAuthorityList(users.getAuthorities().split(",")));
        }
        return null;
    }
}

package com.xz.oauth2.dao;

import com.xz.oauth2.entity.dto.Scope;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ScopeDao {

}

package com.xz.oauth2.dao;


import com.xz.oauth2.entity.dto.Client;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ClientDao {
    @Select("select * from client")
    List<Client> findByAll();
}
